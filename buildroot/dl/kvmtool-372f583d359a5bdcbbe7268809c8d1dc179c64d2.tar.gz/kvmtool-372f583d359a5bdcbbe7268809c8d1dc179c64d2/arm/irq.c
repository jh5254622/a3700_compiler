#include "kvm/irq.h"
#include "kvm/kvm.h"
#include "kvm/util.h"

int irq__add_msix_route(struct kvm *kvm, struct msi_msg *msg)
{
	die(__FUNCTION__);
	return 0;
}
