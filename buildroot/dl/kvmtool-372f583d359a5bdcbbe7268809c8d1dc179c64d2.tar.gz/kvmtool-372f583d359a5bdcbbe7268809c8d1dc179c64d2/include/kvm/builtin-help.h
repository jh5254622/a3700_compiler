#ifndef __KVM_HELP_H__
#define __KVM_HELP_H__

int kvm_cmd_help(int argc, const char **argv, const char *prefix);

#endif
