#include "kvm/kvm.h"

#include <stdbool.h>

bool kvm__load_firmware(struct kvm *kvm, const char *firmware_filename)
{
	return false;
}
