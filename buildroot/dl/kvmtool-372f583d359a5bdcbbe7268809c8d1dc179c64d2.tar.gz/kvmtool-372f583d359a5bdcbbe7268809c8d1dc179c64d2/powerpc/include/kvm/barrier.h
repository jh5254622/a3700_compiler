#ifndef _KVM_BARRIER_H_
#define _KVM_BARRIER_H_

#include <asm/barrier.h>

#endif /* _KVM_BARRIER_H_ */
